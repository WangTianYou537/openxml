//! Create a PowerPoint presentation and embed `slide-1.svg` on the first slide.

use openxml::namespace::content_type;
use openxml::packaging::{PresentationDocument, PresentationDocumentType};

fn main() -> openxml::Result<()> {
    let out = std::env::args()
        .nth(1)
        .unwrap_or_else(|| "/opt/wp/openxml/slide-1.pptx".into());
    let svg_path = std::env::args()
        .nth(2)
        .unwrap_or_else(|| "/opt/wp/openxml/slide-1.svg".into());

    let svg_bytes = std::fs::read(&svg_path)?;

    // SVG viewBox is 1280×720; map to a standard 16:9 slide (13.333" × 7.5")
    // EMU: 914400 per inch → 12192000 × 6858000
    const SLIDE_CX: i64 = 12_192_000;
    const SLIDE_CY: i64 = 6_858_000;

    let mut ppt =
        PresentationDocument::create(&out, PresentationDocumentType::Presentation)?;
    ppt.add_blank_slide()?;

    // Full-bleed picture covering the slide
    let (uri, rid) = ppt.add_image_on_slide(
        0,
        &svg_bytes,
        content_type::IMAGE_SVG,
        "svg",
        0,
        0,
        SLIDE_CX,
        SLIDE_CY,
        "slide-1",
    )?;

    ppt.set_title("slide-1.svg")?;
    ppt.set_creator("openxml-rs")?;
    ppt.set_app_slides(1)?;
    ppt.save()?;

    println!("wrote {out}");
    println!("  embedded SVG part: {} (rel {rid})", uri.as_str());
    Ok(())
}
